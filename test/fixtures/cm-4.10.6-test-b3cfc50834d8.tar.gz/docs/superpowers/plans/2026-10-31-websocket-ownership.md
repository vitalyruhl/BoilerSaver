# WebSocket Connection Ownership Repair

## Scope and authorization

The owner requested investigation and repair of the BoilerSaver/CM panics in the test environment only. Production remains on recovered BoilerSaver 4.0.4. Do not upload to production, modify shared dependency installations, publish, or change SIL/SBT/uartTestEsp.

The observed production panic has no backtrace yet. Treat the separately verified WebSocket lifetime defect as a repairable defect, not as an established explanation of that panic.

## Verified defect and design

CM 4.10.5 obtains raw WebSocket client pointers in its main-loop delivery path while the pinned ESPAsyncWebServer-esphome 3.4.0 disconnect handler can remove and destroy those clients concurrently. CM's subscription/delivery reservation does not reserve the transport client.

Use a private CM worktree and the maintained ESP32Async/ESPAsyncWebServer 3.12.1 with AsyncTCP 3.5.0. Its server methods hold `_ws_clients_lock` across lookup and use; its queues and disconnect writes share `_queue_lock`. Replace main-loop raw-client operations with those guarded server methods. Merely upgrading while retaining borrowed pointers is insufficient.

Preserve one outstanding runtime payload per client by retaining the existing delivery reservation until the shared outgoing buffer is released. Preserve selected groups, custom runtime builders, independent slow/healthy clients, copied payload bytes, and nonblocking generation behavior.

## Implementation sequence

1. Add a deterministic host regression for a connection disappearing before delivery; establish failure against the current raw-client contract without accessing freed memory.
2. Adapt runtime delivery to guarded server-by-ID APIs and shared outgoing-buffer ownership. Remove remaining main-loop raw-client lookups from heartbeat/close/delivery paths.
3. Pin the maintained transport pair in package and consumer build metadata. Classify as a compatible patch; synchronize the canonical version and required mirrors to the unpublished 4.10.6 candidate.
4. Update host transport doubles and retain the existing backpressure/selection/generation checks.
5. Run focused host checks, relevant firmware builds, and an independent code review. Freeze exact artifacts before integrating the private candidate into a separate BoilerSaver test profile.
6. Test only on the documented COM8 development station, using OneWire18, I2C21/22, LED25 as the unloaded boiler output, buttons14/33/4, and no OLED reset pin. Do not register relay pins19/27/23.

## Acceptance and limits

- No main-loop client-pointer dereference spans an uncoordinated disconnect.
- Disconnected/full/rejected delivery releases its reservation; accepted delivery retains it until transport buffer release.
- A stalled transport queue retains at most one CM runtime payload per client.
  Transport release may precede a network ACK after TCP copies the bytes; TCP's
  own bounded window is separate from the CM buffer reservation.
- Selected payloads, legacy clients, and generation locks retain their existing behavior.
- Record real peripheral presence, exact BIN/ELF hashes, reset reasons, and any backtrace separately from synthetic host fixtures.
- A passing test does not authorize a production deployment or prove the historic panic's cause.
