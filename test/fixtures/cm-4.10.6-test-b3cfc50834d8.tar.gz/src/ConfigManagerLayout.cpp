#include <algorithm>
#include "ConfigManager.h"
#include "web/JsonOutput.h"
#include "runtime/detail/LiveLayoutJson.h"
#include "runtime/detail/LivePageSelection.h"

namespace {
String resolveLayoutLabel(const char* provided, const String& fallback) {
  if (provided && provided[0] != '\0') {
    return String(provided);
  }
  if (!fallback.isEmpty()) {
    return fallback;
  }
  return String(ConfigManagerClass::DEFAULT_LAYOUT_NAME);
}
} // namespace
// Cppcheck rationale: Preserve the existing instance API for source compatibility.
// cppcheck-suppress functionStatic
String ConfigManagerClass::normalizeLayoutName(const String& value) const {
  String normalized = value;
  normalized.trim();
  normalized.toLowerCase();
  return normalized;
}

void ConfigManagerClass::logLayoutWarningOnce(const String& key, const String& message) {
#if CM_ENABLE_LIVE_UI || CM_ENABLE_SETTINGS_UI

  if (layoutWarnings.insert(key).second) {
    CM_CORE_LOG("[WARNING] %s", message.c_str());
  }

#else

#endif
}

ConfigManagerClass::LayoutPage* ConfigManagerClass::findLayoutPage(std::vector<LayoutPage>& pages, const String& normalized) {
  for (auto& page : pages) {
    // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
    // cppcheck-suppress useStlAlgorithm
    if (normalizeLayoutName(page.name) == normalized) {
      return &page;
    }
  }
  return nullptr;
}

// Cppcheck rationale: The returned nested layout card remains mutable for callers.
// cppcheck-suppress constParameterReference
ConfigManagerClass::LayoutCard* ConfigManagerClass::findLayoutCard(LayoutPage& page, const String& normalized) {
  for (auto& card : page.cards) {
    // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
    // cppcheck-suppress useStlAlgorithm
    if (normalizeLayoutName(card.name) == normalized) {
      return &card;
    }
  }
  return nullptr;
}

// Cppcheck rationale: The returned nested layout group remains mutable for callers.
// cppcheck-suppress constParameterReference
ConfigManagerClass::LayoutGroup* ConfigManagerClass::findLayoutGroup(LayoutCard& card, const String& normalized) {
  for (auto& group : card.groups) {
    // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
    // cppcheck-suppress useStlAlgorithm
    if (normalizeLayoutName(group.name) == normalized) {
      return &group;
    }
  }
  return nullptr;
}

ConfigManagerClass::LayoutPage& ConfigManagerClass::ensureLayoutPage(std::vector<LayoutPage>& pages, const char* name, int order, bool warnOnCreate) {
  String resolvedName = resolveLayoutLabel(name, String(DEFAULT_LAYOUT_NAME));
  String normalized = normalizeLayoutName(resolvedName);
  if (auto* existing = findLayoutPage(pages, normalized)) {
    if (order >= 0) {
      existing->order = order;
    }
    return *existing;
  }

  LayoutPage page;
  page.name = resolvedName;
  page.order = (order >= 0) ? order : DEFAULT_LAYOUT_ORDER;
  pages.push_back(page);
  if (warnOnCreate) {
    logLayoutWarningOnce("page:" + normalized, "Layout page '" + resolvedName + "' was auto-created");
  }
  return pages.back();
}

ConfigManagerClass::LayoutCard& ConfigManagerClass::ensureLayoutCard(LayoutPage& page, const char* name, int order, const String& fallbackName, bool warnOnCreate) {
  String resolvedName = resolveLayoutLabel(name, fallbackName);
  String normalized = normalizeLayoutName(resolvedName);
  if (auto* existing = findLayoutCard(page, normalized)) {
    if (order >= 0) {
      existing->order = order;
    }
    return *existing;
  }

  LayoutCard card;
  card.name = resolvedName;
  card.order = (order >= 0) ? order : DEFAULT_LAYOUT_ORDER;
  page.cards.push_back(card);
  if (warnOnCreate) {
    logLayoutWarningOnce("card:" + normalized, "Layout card '" + resolvedName + "' was auto-created in page '" + page.name + "'");
  }
  return page.cards.back();
}

ConfigManagerClass::LayoutGroup& ConfigManagerClass::ensureLayoutGroup(LayoutCard& card, const char* name, int order, const String& fallbackName, bool warnOnCreate) {
  String resolvedName = resolveLayoutLabel(name, fallbackName);
  String normalized = normalizeLayoutName(resolvedName);
  if (auto* existing = findLayoutGroup(card, normalized)) {
    if (order >= 0) {
      existing->order = order;
    }
    return *existing;
  }

  LayoutGroup group;
  group.name = resolvedName;
  group.order = (order >= 0) ? order : DEFAULT_LAYOUT_ORDER;
  card.groups.push_back(group);
  if (warnOnCreate) {
    logLayoutWarningOnce("group:" + normalized, "Layout group '" + resolvedName + "' was auto-created in card '" + card.name + "'");
  }
  return card.groups.back();
}

void ConfigManagerClass::addSettingsPage(const char* pageName, int order) {
#if CM_ENABLE_SETTINGS_UI

  ensureLayoutPage(settingsPages, pageName, order, false);

#else

#endif
}

void ConfigManagerClass::addSettingsCard(const char* pageName, const char* cardName, int order) {
#if CM_ENABLE_SETTINGS_UI

  String resolvedPageName = resolveLayoutLabel(pageName, String(DEFAULT_LAYOUT_NAME));
  String normalizedPage = normalizeLayoutName(resolvedPageName);
  bool pageExists = findLayoutPage(settingsPages, normalizedPage) != nullptr;
  LayoutPage& page = ensureLayoutPage(settingsPages, pageName, -1, !pageExists);
  ensureLayoutCard(page, cardName, order, page.name, false);

#else

#endif
}

void ConfigManagerClass::addSettingsGroup(const char* pageName, const char* cardName, const char* groupName, int order) {
#if CM_ENABLE_SETTINGS_UI

  String resolvedPageName = resolveLayoutLabel(pageName, String(DEFAULT_LAYOUT_NAME));
  String normalizedPage = normalizeLayoutName(resolvedPageName);
  bool pageExists = findLayoutPage(settingsPages, normalizedPage) != nullptr;
  LayoutPage& page = ensureLayoutPage(settingsPages, pageName, -1, !pageExists);
  LayoutCard& card = ensureLayoutCard(page, cardName, -1, page.name, false);
  ensureLayoutGroup(card, groupName, order, card.name, false);

#else

#endif
}

void ConfigManagerClass::addLivePage(const char* pageName, int order) {
#if CM_ENABLE_LIVE_UI

  liveLayoutEnabled = true;
  ensureLayoutPage(livePages, pageName, order, false);

#else

#endif
}

void ConfigManagerClass::addLiveCard(const char* pageName, const char* cardName, int order) {
#if CM_ENABLE_LIVE_UI

  liveLayoutEnabled = true;
  String resolvedPageName = resolveLayoutLabel(pageName, String(DEFAULT_LAYOUT_NAME));
  String normalizedPage = normalizeLayoutName(resolvedPageName);
  bool pageExists = findLayoutPage(livePages, normalizedPage) != nullptr;
  LayoutPage& page = ensureLayoutPage(livePages, pageName, -1, !pageExists);
  ensureLayoutCard(page, cardName, order, String(DEFAULT_LIVE_CARD_NAME), false);

#else

#endif
}

void ConfigManagerClass::addLiveGroup(const char* pageName, const char* cardName, const char* groupName, int order) {
#if CM_ENABLE_LIVE_UI

  liveLayoutEnabled = true;
  String resolvedPageName = resolveLayoutLabel(pageName, String(DEFAULT_LAYOUT_NAME));
  String normalizedPage = normalizeLayoutName(resolvedPageName);
  bool pageExists = findLayoutPage(livePages, normalizedPage) != nullptr;
  LayoutPage& page = ensureLayoutPage(livePages, pageName, -1, !pageExists);
  LayoutCard& card = ensureLayoutCard(page, cardName, -1, String(DEFAULT_LIVE_CARD_NAME), false);
  ensureLayoutGroup(card, groupName, order, card.name, false);

#else

#endif
}

void ConfigManagerClass::setCategoryLayoutOverride(const char* category, const char* page, const char* card, const char* group, int order) {
#if CM_ENABLE_LIVE_UI || CM_ENABLE_SETTINGS_UI

  if (!category || category[0] == '\0')
    return;

  CategoryLayoutOverride overrideEntry;
  overrideEntry.page = (page && page[0]) ? String(page) : String();
  overrideEntry.card = (card && card[0]) ? String(card) : String();
  overrideEntry.group = (group && group[0]) ? String(group) : String();
  overrideEntry.order = order;
  categoryLayoutOverrides[String(category)] = overrideEntry;

#else

#endif
}

const ConfigManagerClass::CategoryLayoutOverride* ConfigManagerClass::getCategoryLayoutOverride(const char* category) const {
#if CM_ENABLE_LIVE_UI || CM_ENABLE_SETTINGS_UI

  if (!category || category[0] == '\0') {
    return nullptr;
  }
  auto it = categoryLayoutOverrides.find(String(category));
  if (it == categoryLayoutOverrides.end()) {
    return nullptr;
  }
  return &it->second;

#else
  return nullptr;
#endif
}

// Cppcheck rationale: Preserve the mutable callback and extension contract.
// cppcheck-suppress constParameterPointer
void ConfigManagerClass::registerSettingPlacement(BaseSetting* setting) {
#if CM_ENABLE_SETTINGS_UI

  if (!setting || !setting->shouldShowInWeb()) {
    return;
  }

  const char* category = setting->getCategory();
  String pageName = (category && category[0]) ? String(category) : String(DEFAULT_LAYOUT_NAME);
  String cardName = (setting->getCard() && setting->getCard()[0]) ? String(setting->getCard()) : pageName;
  String groupName = (setting->getCard() && setting->getCard()[0]) ? String(setting->getCard()) : cardName;

  if (const auto* overrideEntry = getCategoryLayoutOverride(category)) {
    if (!overrideEntry->page.isEmpty()) {
      pageName = overrideEntry->page;
      if (overrideEntry->card.isEmpty()) {
        cardName = pageName;
      }
    }
    if (!overrideEntry->card.isEmpty()) {
      cardName = overrideEntry->card;
    }
    if (!overrideEntry->group.isEmpty()) {
      groupName = overrideEntry->group;
    }
  }

  addSettingsCard(pageName.c_str(), cardName.c_str(), setting->getCardOrder());
  addSettingsGroup(pageName.c_str(), cardName.c_str(), groupName.c_str(), setting->getSortOrder());
  addToSettingsGroup(setting->getKey(), pageName.c_str(), cardName.c_str(), groupName.c_str(), setting->getSortOrder());

#else

#endif
}

namespace {
String resolvePlacementName(const char* provided, const char* fallback) {
  if (provided && provided[0] != '\0')
    return String(provided);
  return fallback ? String(fallback) : String{};
}
} // namespace

void ConfigManagerClass::addToSettings(const char* itemId, const char* pageName, int order) {
#if CM_ENABLE_SETTINGS_UI

  addToSettingsGroup(itemId, pageName, pageName, pageName, order);

#else

#endif
}

void ConfigManagerClass::addToSettingsGroup(const char* itemId, const char* pageName, const char* groupName, int order) {
#if CM_ENABLE_SETTINGS_UI

  addToSettingsGroup(itemId, pageName, pageName, groupName, order);

#else

#endif
}

void ConfigManagerClass::addToSettingsGroup(const char* itemId, const char* pageName, const char* cardName, const char* groupName, int order) {
#if CM_ENABLE_SETTINGS_UI

  String resolvedPage = resolvePlacementName(pageName, DEFAULT_LAYOUT_NAME);
  String resolvedCard = resolvePlacementName(cardName, resolvedPage.c_str());
  String resolvedGroup = resolvePlacementName(groupName, resolvedCard.c_str());
  addSettingsGroup(resolvedPage.c_str(), resolvedCard.c_str(), resolvedGroup.c_str(), order);
  settingsPlacements.push_back({itemId, resolvedPage, resolvedCard, resolvedGroup, order});

#else

#endif
}

void ConfigManagerClass::addToLive(const char* itemId, const char* pageName, int order) {
#if CM_ENABLE_LIVE_UI

  addToLiveGroup(itemId, pageName, DEFAULT_LIVE_CARD_NAME, DEFAULT_LIVE_CARD_NAME, order);

#else

#endif
}

void ConfigManagerClass::addToLiveCard(const char* itemId, const char* pageName, const char* cardName, int order) {
#if CM_ENABLE_LIVE_UI

  String resolvedPage = resolvePlacementName(pageName, DEFAULT_LAYOUT_NAME);
  String resolvedCard = resolvePlacementName(cardName, DEFAULT_LIVE_CARD_NAME);
  addLiveCard(resolvedPage.c_str(), resolvedCard.c_str(), order);
  livePlacements.push_back({itemId, resolvedPage, resolvedCard, String(), order});

#else

#endif
}

void ConfigManagerClass::addToLiveGroup(const char* itemId, const char* pageName, const char* groupName, int order) {
#if CM_ENABLE_LIVE_UI

  addToLiveGroup(itemId, pageName, DEFAULT_LIVE_CARD_NAME, groupName, order);

#else

#endif
}

void ConfigManagerClass::addToLiveGroup(const char* itemId, const char* pageName, const char* cardName, const char* groupName, int order) {
#if CM_ENABLE_LIVE_UI

  String resolvedPage = resolvePlacementName(pageName, DEFAULT_LAYOUT_NAME);
  String resolvedCard = resolvePlacementName(cardName, DEFAULT_LIVE_CARD_NAME);
  String resolvedGroup = resolvePlacementName(groupName, resolvedCard.c_str());
  addLiveGroup(resolvedPage.c_str(), resolvedCard.c_str(), resolvedGroup.c_str(), order);
  livePlacements.push_back({itemId, resolvedPage, resolvedCard, resolvedGroup, order});

#else

#endif
}

void ConfigManagerClass::registerLivePlacement(const RuntimeFieldMeta& meta) {
#if CM_ENABLE_LIVE_UI

  registerLivePlacement(cm::RuntimeMetaView(meta));

#else

#endif
}

void ConfigManagerClass::registerLivePlacement(const cm::RuntimeMetaView& meta) {
#if CM_ENABLE_LIVE_UI

  if (meta.key.isEmpty()) {
    return;
  }

  const String identitySource = meta.sourceGroup.length() ? meta.sourceGroup : meta.group;
  String pageName = meta.page;
  String cardName = meta.card;
  String groupName = meta.group;
  pageName.trim();
  cardName.trim();
  groupName.trim();

  if (!pageName.isEmpty()) {
    liveLayoutEnabled = true;
  }

  if (cardName.isEmpty() && groupName.length()) {
    cardName = groupName;
    groupName = String();
  }

  String resolvedPage = pageName;
  String resolvedCard = cardName;
  String resolvedGroup = groupName;

  if (!liveLayoutEnabled) {
    for (auto& placement : livePlacements) {
      // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
      // cppcheck-suppress useStlAlgorithm
      if (cm::sameLiveField(placement, meta.key.c_str(), identitySource.c_str())) {
        placement.page = resolvedPage;
        placement.card = resolvedCard;
        placement.group = resolvedGroup;
        placement.order = meta.order;
        return;
      }
    }
    livePlacements.push_back({meta.key, resolvedPage, resolvedCard, resolvedGroup, meta.order, identitySource});
    return;
  }

  if (resolvedPage.isEmpty()) {
    const String sourceGroup = meta.sourceGroup.length() ? meta.sourceGroup : meta.group;
    if (sourceGroup.equalsIgnoreCase("system")) {
      resolvedPage = "System";
      if (resolvedCard.isEmpty()) {
        resolvedCard = "System";
      }
    }
    if (resolvedPage.isEmpty() && sourceGroup.length()) {
      const String normalizedTarget = normalizeLayoutName(sourceGroup);
      for (const auto& page : livePages) {
        if (!resolvedPage.isEmpty()) {
          break;
        }
        for (const auto& card : page.cards) {
          if (!resolvedPage.isEmpty()) {
            break;
          }
          // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
          // cppcheck-suppress useStlAlgorithm
          if (normalizeLayoutName(card.name) == normalizedTarget) {
            resolvedPage = page.name;
            resolvedCard = card.name;
            resolvedGroup = String();
            break;
          }
          for (const auto& group : card.groups) {
            // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
            // cppcheck-suppress useStlAlgorithm
            if (normalizeLayoutName(group.name) == normalizedTarget) {
              resolvedPage = page.name;
              resolvedCard = card.name;
              resolvedGroup = group.name;
              break;
            }
          }
        }
      }
    }
  }

  resolvedPage = resolvePlacementName(resolvedPage.c_str(), DEFAULT_LAYOUT_NAME);
  resolvedCard = resolvePlacementName(resolvedCard.c_str(), DEFAULT_LIVE_CARD_NAME);

  addLivePage(resolvedPage.c_str(), -1);
  addLiveCard(resolvedPage.c_str(), resolvedCard.c_str(), -1);

  if (!resolvedGroup.isEmpty()) {
    resolvedGroup = resolvePlacementName(resolvedGroup.c_str(), resolvedCard.c_str());
    addLiveGroup(resolvedPage.c_str(), resolvedCard.c_str(), resolvedGroup.c_str(), -1);
  }

  for (auto& placement : livePlacements) {
    // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
    // cppcheck-suppress useStlAlgorithm
    if (cm::sameLiveField(placement, meta.key.c_str(), identitySource.c_str())) {
      placement.page = resolvedPage;
      placement.card = resolvedCard;
      placement.group = resolvedGroup;
      placement.order = meta.order;
      return;
    }
  }

  livePlacements.push_back({meta.key, resolvedPage, resolvedCard, resolvedGroup, meta.order, identitySource});

#else

#endif
}

// Cppcheck rationale: Retain the established runtime-group terminology in this API.
// cppcheck-suppress shadowFunction
void ConfigManagerClass::registerLivePlacement(const String& liveGroup,
                                               const String& key,
                                               const String& label,
                                               int order) {
#if CM_ENABLE_LIVE_UI

  if (key.isEmpty()) {
    return;
  }
  liveLayoutEnabled = true;

  String resolvedGroup = liveGroup;
  resolvedGroup.trim();
  if (resolvedGroup.isEmpty() && !label.isEmpty()) {
    resolvedGroup = label;
    resolvedGroup.trim();
  }
  if (resolvedGroup.isEmpty()) {
    resolvedGroup = String(DEFAULT_LIVE_CARD_NAME);
  }

  String resolvedPage = String(DEFAULT_LAYOUT_NAME);
  String resolvedCard = resolvedGroup;
  String resolvedLayoutGroup = resolvedGroup;

  const auto* overrideEntry = getCategoryLayoutOverride(resolvedGroup.c_str());
  if (overrideEntry) {
    if (!overrideEntry->page.isEmpty()) {
      resolvedPage = overrideEntry->page;
      if (overrideEntry->card.isEmpty()) {
        resolvedCard = resolvedPage;
      }
    }
    if (!overrideEntry->card.isEmpty()) {
      resolvedCard = overrideEntry->card;
    }
    if (!overrideEntry->group.isEmpty()) {
      resolvedLayoutGroup = overrideEntry->group;
    }
  } else {
    const String wantedNorm = normalizeLayoutName(resolvedGroup);
    bool found = false;

    // 1) Prefer matching an explicitly defined Live group (by normalized token).
    for (const auto& page : livePages) {
      for (const auto& card : page.cards) {
        for (const auto& group : card.groups) {
          // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
          // cppcheck-suppress useStlAlgorithm
          if (normalizeLayoutName(group.name) == wantedNorm) {
            resolvedPage = page.name;
            resolvedCard = card.name;
            resolvedLayoutGroup = group.name;
            found = true;
            break;
          }
        }
        if (found) {
          break;
        }
      }
      if (found) {
        break;
      }
    }

    // 2) If no group exists yet, try matching a defined card (and use it as group).
    if (!found) {
      for (const auto& page : livePages) {
        for (const auto& card : page.cards) {
          // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
          // cppcheck-suppress useStlAlgorithm
          if (normalizeLayoutName(card.name) == wantedNorm) {
            resolvedPage = page.name;
            resolvedCard = card.name;
            resolvedLayoutGroup = card.name;
            found = true;
            break;
          }
        }
        if (found) {
          break;
        }
      }
    }

    // 3) If still not found, try matching a defined page (fallback to default card/group tokens).
    if (!found) {
      for (const auto& page : livePages) {
        // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
        // cppcheck-suppress useStlAlgorithm
        if (normalizeLayoutName(page.name) == wantedNorm) {
          resolvedPage = page.name;
          break;
        }
      }
    }
  }

  // Ensure the layout target exists without overriding existing group order with per-field order.
  addLiveGroup(resolvedPage.c_str(), resolvedCard.c_str(), resolvedLayoutGroup.c_str(), -1);

  for (auto& placement : livePlacements) {
    // Cppcheck rationale: Keep the allocation-free, early-exit loop on the embedded target.
    // cppcheck-suppress useStlAlgorithm
    if (placement.id == key) {
      placement.page = resolvedPage;
      placement.card = resolvedCard;
      placement.group = resolvedLayoutGroup;
      placement.order = order;
      return;
    }
  }

  livePlacements.push_back({key, resolvedPage, resolvedCard, resolvedLayoutGroup, order});

#else

#endif
}

bool ConfigManagerClass::supportsLivePageSelection() const {
#if CM_ENABLE_LIVE_UI

  if (!liveLayoutEnabled)
    return false;
  return std::all_of(livePages.begin(), livePages.end(), [this](const auto& page) {
    const String key = normalizeLayoutName(page.name);
    return key.length() && key.length() <= 256 && key != "__unassigned__";
  });

#else
  return false;
#endif
}

String ConfigManagerClass::livePageKeyForField(const String& fieldKey, const String& sourceGroup) const {
#if CM_ENABLE_LIVE_UI

  const UiPlacement* selected = cm::findLivePlacement(livePlacements, fieldKey.c_str(), sourceGroup.c_str());
  if (selected) {
    const String key = normalizeLayoutName(selected->page);
    if (std::any_of(livePages.begin(), livePages.end(), [&](const auto& page) { return normalizeLayoutName(page.name) == key; }))
      return key;
  }
  return "__unassigned__";

#else
  return {};
#endif
}

bool ConfigManagerClass::hasLivePageKey(const String& pageKey) const {
#if CM_ENABLE_LIVE_UI

  if (!supportsLivePageSelection())
    return false;
  if (std::any_of(livePages.begin(), livePages.end(), [&](const auto& page) { return normalizeLayoutName(page.name) == pageKey; }))
    return true;
  return pageKey == "__unassigned__" && runtimeManager.hasRuntimeMetaView([&](const cm::RuntimeMetaView& meta) {
    return livePageKeyForField(meta.key, meta.sourceGroup.length() ? meta.sourceGroup : meta.group) == pageKey;
  });

#else
  return false;
#endif
}

String ConfigManagerClass::buildLivePageIndexJSON() const {
#if CM_ENABLE_LIVE_UI

  const bool scoped = supportsLivePageSelection();
  const bool hasContent = !livePages.empty() || runtimeManager.hasRuntimeMeta();
  const bool hasUnassigned = scoped && hasLivePageKey("__unassigned__");
  const auto normalize = [this](const String& value) { return normalizeLayoutName(value); };
  const auto emitIndex = [&](auto& sink) {
    return cm::writeLivePageIndexJson(sink, livePages, scoped, hasContent, hasUnassigned, normalize);
  };
  String output;
  if (!cm::buildJsonOutput(emitIndex, output))
    return String();
  return output;

#else
  return {};
#endif
}

String ConfigManagerClass::buildLivePageMetadataJSON(const String& pageKey) {
#if CM_ENABLE_LIVE_UI

  return runtimeManager.runtimeMetaToJSONView([&](const cm::RuntimeMetaView& meta) {
    return livePageKeyForField(meta.key, meta.sourceGroup.length() ? meta.sourceGroup : meta.group) == pageKey;
  });

#else
  return {};
#endif
}

String ConfigManagerClass::buildLiveLayoutJSON() const {
#if CM_ENABLE_LIVE_UI

  return buildLiveLayoutJSONImpl(nullptr);

#else
  return {};
#endif
}
String ConfigManagerClass::buildLiveLayoutJSON(const String& pageKey) const {
#if CM_ENABLE_LIVE_UI

  return buildLiveLayoutJSONImpl(&pageKey);

#else
  return {};
#endif
}

String ConfigManagerClass::buildLiveLayoutJSONImpl(const String* pageKey) const {
#if CM_ENABLE_LIVE_UI

  const auto normalize = [this](const String& value) { return normalizeLayoutName(value); };
  const auto emitLayout = [&](auto& sink) {
    return cm::writeLiveLayoutJson(sink, livePages, livePlacements, liveLayoutEnabled, pageKey, normalize);
  };
  String output;
  if (!cm::buildJsonOutput(emitLayout, output))
    return String();
  return output;

#else
  return {};
#endif
}
