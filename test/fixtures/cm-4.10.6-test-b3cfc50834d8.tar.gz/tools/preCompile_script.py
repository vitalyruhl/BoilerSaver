import os
import subprocess
import gzip
import shutil
import sys
import json
import hashlib

from pathlib import Path

# Try to access PlatformIO/SCons build environment to read CPPDEFINES
try:
	from SCons.Script import Import  # type: ignore
	Import('env')  # provides "env" from PlatformIO
except Exception:
	env = None

def _find_executable(*names: str) -> str:
	for name in names:
		path = shutil.which(name)
		if path:
			return path
	raise RuntimeError(f"Required executable not found on PATH: {', '.join(names)}")



def _resolve_repo_root() -> Path:
	"""Resolve repository root in a PlatformIO/SCons-friendly way.

	Note: extra_scripts are executed via exec() and may not define __file__.
	"""
	if env is not None:
		proj_dir_raw = env.get('PROJECT_DIR') or env.subst('$PROJECT_DIR')
		project_dir = Path(str(proj_dir_raw)).resolve()
	else:
		project_dir = Path.cwd().resolve()

	# Look upwards for a folder that contains both 'webui' and 'tools'.
	candidates = [project_dir]
	for _ in range(4):
		candidates.append(candidates[-1].parent)
	for candidate in candidates:
		if (candidate / 'webui').is_dir() and (candidate / 'tools').is_dir():
			return candidate

	return project_dir


ROOT_DIR = _resolve_repo_root()
WEBUI_DIR = ROOT_DIR / 'webui'
HEADER_PATH = ROOT_DIR / 'src' / 'html_content.h'

def _get_define_from_scons(name: str, default: str) -> str:
	"""Read a -D define from PlatformIO/SCons if available; return default otherwise."""
	if env is None:
		return default
	try:
		defines = env.get('CPPDEFINES', [])
		for d in defines:
			if isinstance(d, tuple) and len(d) == 2:
				k, v = d
				if k == name:
					return str(v)
			elif isinstance(d, str) and d == name:
				return '1'
	except Exception:
		return default
	return default


# Resolve the same compiler values in SCons and wrapper subprocesses.
sys.path.insert(0, str(ROOT_DIR / 'tools'))
from webui_features import feature_values, source_fingerprint
features = feature_values(env)
FEATURE_ENV = {
	'VITE_CM_ENABLE_LOGGING': _get_define_from_scons('CM_ENABLE_LOGGING', '1'),
	'VITE_CM_ENABLE_VERBOSE_LOGGING': _get_define_from_scons('CM_ENABLE_VERBOSE_LOGGING', '0'),
}
FEATURE_ENV.update({'VITE_' + key: value for key, value in features.items()})


EMBED_WEBUI = features['CM_EMBED_WEBUI'] == '1'
CACHE_PATH = ROOT_DIR / '.pio' / 'cm-webui-build.json'
fingerprint = source_fingerprint(ROOT_DIR, {**features, 'NODE_ENV': os.environ.get('NODE_ENV', 'production')})
try:
	cached = json.loads(CACHE_PATH.read_text())
except (OSError, ValueError):
	cached = {}
header_hash = hashlib.sha256(HEADER_PATH.read_bytes()).hexdigest() if HEADER_PATH.exists() else None
CACHE_MATCH = cached.get('fingerprint') == fingerprint and cached.get('header_sha256') == header_hash


if EMBED_WEBUI and not CACHE_MATCH:
	npm_cmd = _find_executable('npm.cmd', 'npm')
	node_exe = _find_executable('node.exe', 'node')
	# Ensure node modules present only when embedding
	if not (WEBUI_DIR / 'node_modules' / 'vite' / 'bin' / 'vite.js').exists():
		subprocess.run([npm_cmd, 'ci'], cwd=str(WEBUI_DIR), check=True)

	# Prepare environment
	env_vars = os.environ.copy()
	env_vars.update(FEATURE_ENV)

	# Passwords are transmitted in plaintext over HTTP in v3.0.0.

	# 1. Build Vue app with feature env
	subprocess.run([npm_cmd, 'run', 'build'], cwd=str(WEBUI_DIR), check=True, env=env_vars)

	# 1b. Gzip compress dist/index.html to reduce flash footprint before header conversion
	dist_index = WEBUI_DIR / 'dist' / 'index.html'
	if dist_index.exists():
		raw = dist_index.read_bytes()
		gz_path = dist_index.with_suffix('.html.gz')
		with gzip.open(gz_path, 'wb', compresslevel=9) as gz:
			gz.write(raw)

	# 2. Generate header from built assets (invoke the moved generator in tools/)
	try:
		root_dir = ROOT_DIR
		generator = root_dir / 'tools' / 'webui_to_header.js'
		if not generator.exists():
			raise FileNotFoundError(f"Header generator not found at {generator}")
		# Pass environment variables to header generator
		subprocess.run([node_exe, str(generator)], cwd=str(root_dir), check=True, env=env_vars)
		CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
		CACHE_PATH.write_text(json.dumps({'fingerprint': fingerprint, 'features': features,
			'header_sha256': hashlib.sha256(HEADER_PATH.read_bytes()).hexdigest()}, indent=2) + '\n')
	except Exception as e:
		raise RuntimeError(f"Failed to run webui_to_header.js: {e}")

elif EMBED_WEBUI:
	print('[I] Embedded UI cache matches source, compiler flags, and generated header.')
else:
	stub = (
		"#pragma once\n"
		"#include <pgmspace.h>\n\n"
		"// Minimal stub when embedded WebUI is disabled\n"
		"const char WEB_HTML[] PROGMEM =\n"
		'R"HTML(<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WebUI disabled</title><style>body{font-family:sans-serif;background:#111;color:#ddd;margin:2rem} .note{padding:1rem;border:1px solid #333;border-radius:8px;background:#1a1a1a}</style></head><body><h3>Embedded WebUI disabled</h3><div class="note">Use external WebUI. APIs are still available on this device.</div></body></html>)HTML";\n'
	)
	try:
		HEADER_PATH.write_text(stub, encoding='utf-8')
		print(f"[extra_script] Wrote stub header: {HEADER_PATH}")
	except Exception as e:
		print(f"[extra_script] Warning: failed to write stub header: {e}")

	# Also remove any previously built object to force relink without embedded assets
	try:
		env_name = os.environ.get('PIOENV') or os.environ.get('PLATFORMIO_ENV') or ''
		if env_name:
			obj_dir = Path('.pio') / 'build' / env_name / 'src'
			for fname in ['html_content.cpp.o', 'html_content.cpp.o.d']:
				fpath = obj_dir / fname
				if fpath.exists():
					fpath.unlink()
					print(f"[extra_script] Removed stale object: {fpath}")
	except Exception as e:
		print(f"[extra_script] Warning: could not remove old object files: {e}")
